import { Link } from "@tanstack/react-router";
import { useState } from "react";
import { EMAIL, KES, PHONE, PRODUCTS, WA, useCart, type Product } from "@/lib/cart";

const NAV = [["/", "Home"], ["/shop", "Shop"], ["/services", "Services"], ["/about", "About us"], ["/contact", "Contact us"], ["/location", "Our location"]] as const;

export function Header() {
  const { cart, setOpen } = useCart();
  const count = Object.values(cart).reduce((a, b) => a + b, 0);
  return (
    <header className="sticky top-0 z-10 flex flex-wrap items-center gap-3 bg-primary px-5 py-2.5 text-primary-foreground">
      <Link to="/" className="mr-auto font-display text-2xl font-bold text-logo">Pam's Furniture Shop</Link>
      <nav className="flex flex-wrap gap-1">
        {NAV.map(([to, label]) => (
          <Link key={to} to={to} activeOptions={{ exact: true }} className="border-b-2 border-transparent px-3 py-2 hover:border-gold" activeProps={{ className: "border-gold" }}>{label}</Link>
        ))}
      </nav>
      <button onClick={() => setOpen(true)} className="rounded bg-gold px-4 py-2 font-medium text-gold-foreground">Cart ({count})</button>
    </header>
  );
}

export function Footer() {
  return (
    <>
      <a href={`https://wa.me/${WA}`} target="_blank" rel="noopener" className="fixed bottom-4 right-4 z-10 rounded-full bg-whatsapp px-5 py-3 text-primary-foreground shadow-lg">WhatsApp us</a>
      <footer className="bg-primary p-6 text-center text-sm text-primary-foreground">© Pam's Furniture Shop, Eldoret, Kenya · {PHONE} · {EMAIL} · Payments by M-Pesa</footer>
    </>
  );
}

export function ProductImage({ p, className = "" }: { p: Product; className?: string }) {
  if (p.img) return <img src={p.img} alt={p.name} loading="lazy" className={`aspect-[3/2] w-full object-cover ${className}`} />;
  return <div className={`flex aspect-[3/2] w-full items-center justify-center bg-secondary font-display text-2xl text-primary ${className}`}>Photo coming soon</div>;
}

export function ZoomModal({ p, onClose }: { p: Product; onClose: () => void }) {
  const [z, setZ] = useState(1);
  return (
    <div className="fixed inset-0 z-20 flex flex-col items-center justify-center gap-3 bg-overlay p-4 text-primary-foreground" onClick={onClose}>
      <div className="w-full max-w-3xl overflow-hidden rounded-md bg-card" onClick={(e) => e.stopPropagation()}>
        <div style={{ transform: `scale(${z})` }} className="transition-transform"><ProductImage p={p} /></div>
      </div>
      <div className="max-w-3xl text-center" onClick={(e) => e.stopPropagation()}>
        <h3 className="text-2xl text-logo">{p.name} · {KES(p.price)}</h3>
        <p>{p.desc}</p>
        <label className="mx-auto mt-2 block w-72">Zoom<input type="range" min={1} max={3} step={0.1} value={z} onChange={(e) => setZ(+e.target.value)} className="w-full" /></label>
        <button onClick={onClose} className="mt-2 rounded bg-gold px-5 py-2 text-gold-foreground">Close</button>
      </div>
    </div>
  );
}

export function CartDrawer() {
  const { cart, add, clear, open, setOpen } = useCart();
  const [name, setName] = useState(""); const [phone, setPhone] = useState(""); const [county, setCounty] = useState("");
  if (!open) return null;
  const items = Object.entries(cart).map(([id, q]) => ({ p: PRODUCTS.find((x) => x.id === id)!, q })).filter((i) => i.p);
  const total = items.reduce((a, i) => a + i.p.price * i.q, 0);
  const order = () => {
    const msg = `Hello Pam's Furniture Shop, I'd like to order:\n${items.map((i) => `${i.q} x ${i.p.name} (${KES(i.p.price * i.q)})`).join("\n")}\nTotal: ${KES(total)}\nName: ${name}\nPhone: ${phone}\nCounty: ${county}\nI will pay by M-Pesa.`;
    window.open(`https://wa.me/${WA}?text=${encodeURIComponent(msg)}`, "_blank");
    clear();
  };
  const field = "mt-1 w-full rounded border border-input bg-card p-2.5";
  return (
    <div className="fixed inset-0 z-20 flex bg-overlay" onClick={() => setOpen(false)}>
      <div className="ml-auto h-full w-full max-w-md overflow-auto bg-background p-5" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between"><h2 className="text-3xl">Your cart</h2><button onClick={() => setOpen(false)} className="text-muted-foreground">Close</button></div>
        {items.length === 0 ? <p className="mt-4 text-muted-foreground">Your cart is empty.</p> : (
          <>
            {items.map(({ p, q }) => (
              <div key={p.id} className="flex items-center justify-between gap-2 border-b py-2">
                <span className="flex-1 text-sm">{p.name}<br /><small className="text-muted-foreground">{KES(p.price)}</small></span>
                <button onClick={() => add(p.id, -1)} className="h-7 w-7 rounded-full border bg-card">−</button><span>{q}</span>
                <button onClick={() => add(p.id, 1)} className="h-7 w-7 rounded-full border bg-card">+</button>
              </div>
            ))}
            <p className="mt-3 text-lg font-medium">Total: {KES(total)}</p>
            <label className="mt-3 block text-sm">Your name<input className={field} value={name} onChange={(e) => setName(e.target.value)} /></label>
            <label className="mt-3 block text-sm">M-Pesa phone number<input className={field} value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="07..." /></label>
            <label className="mt-3 block text-sm">Delivery county<input className={field} value={county} onChange={(e) => setCounty(e.target.value)} /></label>
            <button disabled={!name || !phone || !county} onClick={order} className="mt-4 w-full rounded bg-gold py-3 font-medium text-gold-foreground disabled:opacity-50">Send order on WhatsApp</button>
            <p className="mt-2 text-sm text-muted-foreground">We'll confirm delivery fees and send M-Pesa payment details.</p>
          </>
        )}
      </div>
    </div>
  );
}
