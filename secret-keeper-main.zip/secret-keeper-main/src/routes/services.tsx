import { createFileRoute } from "@tanstack/react-router";
import { Link } from "@tanstack/react-router";
import { PHONE, WA } from "@/lib/cart";

export const Route = createFileRoute("/services")({
  head: () => ({
    meta: [
      { title: "Our Services | Pam's Furniture Shop" },
      { name: "description", content: "Delivery, M-Pesa payments, WhatsApp ordering, custom furniture and after-sales help from Pam's Furniture Shop in Eldoret." },
      { property: "og:title", content: "Our Services | Pam's Furniture Shop" },
      { property: "og:description", content: "Delivery, M-Pesa payments, WhatsApp ordering, custom furniture and after-sales help from Pam's Furniture Shop in Eldoret." },
      { property: "og:type", content: "website" },
    ],
    links: [{ rel: "canonical", href: "/services" }],
  }),
  component: Services,
});

const SERVICES = [
  {
    title: "Countrywide delivery",
    body: "We deliver across Eldoret and to any county in Kenya. Delivery within Eldoret town is quick, and countrywide deliveries are arranged with trusted transporters.",
  },
  {
    title: "Pay by M-Pesa",
    body: "All payments go through M-Pesa, so every payment is quick, safe and traceable. We send the payment details once your order is confirmed.",
  },
  {
    title: "Order on WhatsApp",
    body: "Pick items in the shop on this website, fill in your name, phone number and county, and your order comes straight to us on WhatsApp.",
  },
  {
    title: "Custom furniture orders",
    body: "Looking for something made to your size, colour or design? Talk to us and we will make furniture to fit your home.",
  },
  {
    title: "Quality check before delivery",
    body: "Every piece is checked before it leaves our shop, so what arrives at your door is ready to use.",
  },
  {
    title: "After-sales help",
    body: "If anything goes wrong with your furniture, call or WhatsApp us and we will sort it out.",
  },
];

function Services() {
  return (
    <section>
      <h2 className="mb-4 mt-8 text-4xl">Our services</h2>
      <p className="max-w-2xl">At Pam's Furniture Shop we do more than sell furniture. Here is everything we provide, from delivery to custom orders.</p>
      <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {SERVICES.map((s) => (
          <div key={s.title} className="rounded border bg-card p-5">
            <h3 className="text-xl">{s.title}</h3>
            <p className="mt-2 text-sm">{s.body}</p>
          </div>
        ))}
      </div>
      <div className="mt-8 rounded border bg-card p-6 text-center">
        <h3 className="text-2xl">Need something special?</h3>
        <p className="mt-2">Call us on {PHONE} or WhatsApp us and we will help you out.</p>
        <div className="mt-4 flex flex-wrap justify-center gap-3">
          <a href={`tel:${PHONE}`} className="rounded bg-primary px-6 py-3 text-primary-foreground">Call {PHONE}</a>
          <a href={`https://wa.me/${WA}`} target="_blank" rel="noopener" className="rounded bg-gold px-6 py-3 text-gold-foreground">WhatsApp us</a>
          <Link to="/shop" className="rounded border border-primary px-6 py-3 text-primary">Browse the shop</Link>
        </div>
      </div>
    </section>
  );
}
