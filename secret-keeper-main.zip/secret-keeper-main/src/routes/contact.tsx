import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { EMAIL, PHONE, WA } from "@/lib/cart";

export const Route = createFileRoute("/contact")({
  head: () => ({
    meta: [
      { title: "Contact Us | Pam's Furniture Shop" },
      { name: "description", content: "Call, WhatsApp or email Pam's Furniture Shop in Eldoret." },
      { property: "og:title", content: "Contact Us | Pam's Furniture Shop" },
      { property: "og:description", content: "Call, WhatsApp or email Pam's Furniture Shop in Eldoret." },
    ],
  }),
  component: Contact,
});

const btn = "my-2 block rounded px-6 py-3 text-center";

function Contact() {
  const [name, setName] = useState(""); const [msg, setMsg] = useState("");
  const field = "mt-1 w-full rounded border bg-background p-2.5";
  return (
    <section>
      <h2 className="mb-4 mt-8 text-4xl">Contact us</h2>
      <div className="grid gap-8 md:grid-cols-2">
        <div className="rounded border bg-card p-6">
          <h3 className="text-2xl">Reach us directly</h3>
          <a className={`${btn} bg-primary text-primary-foreground`} href="tel:0791700514">Call {PHONE}</a>
          <a className={`${btn} bg-gold text-gold-foreground`} href={`https://wa.me/${WA}`} target="_blank" rel="noopener">WhatsApp 0710 914 081</a>
          <a className={`${btn} border border-primary text-primary`} href={`mailto:${EMAIL}`}>{EMAIL}</a>
        </div>
        <div className="rounded border bg-card p-6">
          <h3 className="text-2xl">Send a message</h3>
          <label className="mt-3 block text-sm">Your name<input className={field} value={name} onChange={(e) => setName(e.target.value)} /></label>
          <label className="mt-3 block text-sm">Message<input className={field} value={msg} onChange={(e) => setMsg(e.target.value)} placeholder="Which furniture are you looking for?" /></label>
          <button onClick={() => window.open(`https://wa.me/${WA}?text=${encodeURIComponent(`Hi, I'm ${name}. ${msg}`)}`, "_blank")} className="mt-4 rounded bg-gold px-6 py-3 text-gold-foreground">Send on WhatsApp</button>
        </div>
      </div>
    </section>
  );
}
