import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/location")({
  head: () => ({
    meta: [
      { title: "Our Location | Pam's Furniture Shop" },
      { name: "description", content: "Visit our Eldoret shop or get furniture delivered to any of Kenya's 47 counties." },
      { property: "og:title", content: "Our Location | Pam's Furniture Shop" },
      { property: "og:description", content: "Visit our Eldoret shop or get delivery to all 47 counties." },
    ],
  }),
  component: () => (
    <section>
      <h2 className="mb-4 mt-8 text-4xl">Our location</h2>
      <div className="grid gap-8 md:grid-cols-2">
        <div className="space-y-3 rounded border bg-card p-6">
          <h3 className="text-2xl">Visit our shop</h3>
          <p>Pam's Furniture Shop<br />Uganda Road, Eldoret CBD<br />Eldoret, Uasin Gishu County, Kenya</p>
          <p>Open Monday to Saturday, 8:00 am to 6:00 pm.</p>
          <a className="inline-block rounded bg-gold px-6 py-3 text-gold-foreground" target="_blank" rel="noopener" href="https://www.google.com/maps/search/?api=1&query=Uganda+Road+Eldoret+Kenya">Open in Google Maps</a>
        </div>
        <div className="rounded border bg-card p-6">
          <h3 className="text-2xl">Countrywide delivery</h3>
          <p className="mt-2">We deliver to all 47 counties. We'll confirm the delivery fee for your county when you order.</p>
        </div>
      </div>
    </section>
  ),
});
