import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { z } from "zod";
import { KES, PRODUCTS, ROOMS, useCart, type Product } from "@/lib/cart";
import { ProductImage, ZoomModal } from "@/components/Shell";

export const Route = createFileRoute("/shop")({
  validateSearch: z.object({ room: z.string().optional() }),
  head: () => ({
    meta: [
      { title: "Shop Furniture | Pam's Furniture Shop" },
      { name: "description", content: "Sofas, beds, dining sets, wardrobes and kitchens with prices in KES." },
      { property: "og:title", content: "Shop Furniture | Pam's Furniture Shop" },
      { property: "og:description", content: "Sofas, beds, dining sets, wardrobes and kitchens with prices in KES." },
    ],
  }),
  component: Shop,
});

function Shop() {
  const { room = "all" } = Route.useSearch();
  const nav = useNavigate({ from: "/shop" });
  const [q, setQ] = useState("");
  const [zoom, setZoom] = useState<Product | null>(null);
  const { add, setOpen } = useCart();
  const list = PRODUCTS.filter((p) => (room === "all" || p.room === room) && (p.name + p.desc).toLowerCase().includes(q.toLowerCase()));
  const tab = (k: string, label: string) => (
    <button key={k} onClick={() => nav({ search: k === "all" ? {} : { room: k } })} className={`rounded-full border px-4 py-2 ${room === k ? "border-primary bg-primary text-primary-foreground" : "bg-card"}`}>{label}</button>
  );
  return (
    <section>
      <h2 className="mb-4 mt-8 text-4xl">Our furniture</h2>
      <input type="search" value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search sofa, bed, table, wardrobe..." aria-label="Search products" className="mb-4 w-full rounded border bg-card px-4 py-3" />
      <div className="flex flex-wrap gap-2">{tab("all", "All")}{Object.entries(ROOMS).map(([k, v]) => tab(k, v))}</div>
      <p className="mt-2 text-sm text-muted-foreground">{list.length} products</p>
      <div className="mt-4 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
        {list.map((p) => (
          <div key={p.id} className="flex flex-col overflow-hidden rounded border bg-card">
            <button onClick={() => setZoom(p)} className="cursor-zoom-in" aria-label={`Zoom ${p.name}`}><ProductImage p={p} /></button>
            <div className="flex flex-1 flex-col gap-1 p-3.5">
              <small className="text-muted-foreground">{ROOMS[p.room]}</small>
              <h3 className="font-sans text-base font-medium text-foreground">{p.name}</h3>
              <p className="text-sm text-muted-foreground">{p.desc}</p>
              <b className="mt-auto text-lg text-primary">{KES(p.price)}</b>
              <button onClick={() => { add(p.id); setOpen(true); }} className="mt-1 w-full rounded bg-primary py-2 text-primary-foreground">Add to cart</button>
            </div>
          </div>
        ))}
      </div>
      {zoom && <ZoomModal p={zoom} onClose={() => setZoom(null)} />}
    </section>
  );
}
