import { createFileRoute, Link } from "@tanstack/react-router";
import { PRODUCTS, ROOMS } from "@/lib/cart";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Pam's Furniture Shop | Eldoret, Kenya" },
      { name: "description", content: "Furniture for every room, from Eldoret with countrywide delivery in Kenya. Pay with M-Pesa." },
      { property: "og:title", content: "Pam's Furniture Shop | Eldoret, Kenya" },
      { property: "og:description", content: "Furniture for every room, delivered countrywide in Kenya. Pay with M-Pesa." },
    ],
  }),
  component: Home,
});

const btn = "inline-block rounded px-6 py-3 mr-2 mt-2";

function Home() {
  return (
    <>
      <section className="grid items-center gap-8 py-11 md:grid-cols-[1.1fr_1fr]">
        <div>
          <h1 className="text-5xl md:text-7xl">Furniture made for every room of your home.</h1>
          <p className="mt-4 max-w-[46ch] text-muted-foreground">Solid, comfortable pieces for your living room, dining, kitchen and bedroom. Based in Eldoret and delivered countrywide in Kenya. Pay easily with M-Pesa.</p>
          <Link to="/shop" className={`${btn} bg-gold text-gold-foreground`}>Shop furniture</Link>
          <Link to="/contact" className={`${btn} border border-primary text-primary`}>Talk to us</Link>
        </div>
        <div className="rounded-md bg-primary p-5"><img src="/products/p13.jpg" alt="Modern cream sofa set" className="w-full rounded" /></div>
      </section>
      <h2 className="mb-4 mt-8 text-4xl">Shop by room</h2>
      <div className="mb-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {Object.entries(ROOMS).map(([k, v]) => (
          <Link key={k} to="/shop" search={{ room: k }} className="rounded-sm border border-l-4 border-l-gold bg-card p-5">
            <h3 className="text-3xl">{v}</h3>
            <span className="text-sm text-muted-foreground">{PRODUCTS.filter((p) => p.room === k).length} pieces</span>
          </Link>
        ))}
      </div>
      <div className="grid gap-4 border-t pt-6 sm:grid-cols-3">
        {[["Delivery across Kenya", "From Eldoret to your door in any county."], ["Pay with M-Pesa", "Quick, traceable payments. No cards needed."], ["Zoom every product", "Click a photo to look closely before you buy."]].map(([t, d]) => (
          <div key={t}><h3 className="text-2xl">{t}</h3><p className="text-sm text-muted-foreground">{d}</p></div>
        ))}
      </div>
    </>
  );
}
