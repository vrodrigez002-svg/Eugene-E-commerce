import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/about")({
  head: () => ({
    meta: [
      { title: "About Us | Pam's Furniture Shop" },
      { name: "description", content: "An Eldoret furniture shop equipping Kenyan homes from bedroom to kitchen." },
      { property: "og:title", content: "About Us | Pam's Furniture Shop" },
      { property: "og:description", content: "An Eldoret furniture shop equipping Kenyan homes from bedroom to kitchen." },
    ],
  }),
  component: () => (
    <section>
      <h2 className="mb-4 mt-8 text-4xl">About Pam's Furniture Shop</h2>
      <div className="grid gap-8 md:grid-cols-2">
        <div className="space-y-3">
          <p>Pam's Furniture Shop is an Eldoret furniture shop that equips Kenyan homes from the bedroom to the kitchen. We sell classic designs that last, with a modern finish.</p>
          <p>Every piece is checked before it leaves our shop, and we deliver countrywide. You pay by M-Pesa only, so every payment is quick and traceable.</p>
        </div>
        <div className="rounded border bg-card p-6">
          <h3 className="text-2xl">What we stand for</h3>
          <p className="mt-2">Honest prices in Kenyan shillings.<br />Quality materials and careful finishing.<br />Clear delivery and friendly after-sales help.</p>
        </div>
      </div>
    </section>
  ),
});
