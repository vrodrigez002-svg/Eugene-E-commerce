import { createContext, useContext, useEffect, useState, type ReactNode } from "react";
import products from "./products.json";

export type Product = { id: string; room: string; name: string; price: number; desc: string; img: string | null };
export const PRODUCTS = products as Product[];
export const ROOMS: Record<string, string> = { living: "Living room", dining: "Dining room", kitchen: "Kitchen", bedroom: "Bedroom" };
export const KES = (n: number) => "KES " + n.toLocaleString("en-KE");
export const PHONE = "0791 700 514";
export const WA = "254710914081";
export const EMAIL = "vrodrigez002@gmail.com";

type Cart = Record<string, number>;
const Ctx = createContext<{ cart: Cart; add: (id: string, d?: number) => void; clear: () => void; open: boolean; setOpen: (o: boolean) => void } | null>(null);

export function CartProvider({ children }: { children: ReactNode }) {
  const [cart, setCart] = useState<Cart>({});
  const [open, setOpen] = useState(false);
  useEffect(() => { try { setCart(JSON.parse(localStorage.getItem("pams-cart") || "{}")); } catch { /* ignore */ } }, []);
  const save = (c: Cart) => { setCart(c); localStorage.setItem("pams-cart", JSON.stringify(c)); };
  const add = (id: string, d = 1) => { const n = (cart[id] || 0) + d; const c = { ...cart }; if (n <= 0) delete c[id]; else c[id] = n; save(c); };
  return <Ctx.Provider value={{ cart, add, clear: () => save({}), open, setOpen }}>{children}</Ctx.Provider>;
}
export const useCart = () => useContext(Ctx)!;
